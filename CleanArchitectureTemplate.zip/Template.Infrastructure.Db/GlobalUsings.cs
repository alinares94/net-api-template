﻿global using $safeprojectname$.Context;
global using $safeprojectname$.Repositories;
global using $safeprojectname$.Repositories.Base;
global using $ext_safeprojectname$.Application.Interfaces.Repositories;
global using $ext_safeprojectname$.Application.Interfaces.Repositories.Base;
global using $ext_safeprojectname$.Model.Models;