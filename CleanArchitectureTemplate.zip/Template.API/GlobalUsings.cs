﻿global using Microsoft.AspNetCore.Mvc;
global using $ext_safeprojectname$.Application.Interfaces.Services;