﻿namespace $safeprojectname$.Services;
public class ExternalService : IExternalService
{
}
