﻿namespace $safeprojectname$.Models;
public class Status
{
    public bool Success { get; set; }
}
