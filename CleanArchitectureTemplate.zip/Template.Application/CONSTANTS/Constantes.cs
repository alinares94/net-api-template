﻿namespace $safeprojectname$.Constants;
public class Constantes
{
    public static class Errors
    {
        public const string INTERNAL_DEFAULT_ERROR = "99";
        public const string NOT_FOUND_DEFAULT_ERROR = "98";
    }
}
