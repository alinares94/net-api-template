﻿namespace $safeprojectname$.Dto.Base;
public class DtoBase
{
}
