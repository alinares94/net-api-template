﻿namespace $safeprojectname$.Dto;
public class StatusDto
{
    public bool Success { get; set; }
    public string TestProperty { get; set; } = string.Empty;
}
