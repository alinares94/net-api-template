﻿namespace $safeprojectname$.Interfaces.Repositories.Base;
public interface IBaseRepository : IDisposable
{
}
