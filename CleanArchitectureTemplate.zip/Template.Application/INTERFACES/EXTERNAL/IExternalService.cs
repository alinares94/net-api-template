﻿namespace $safeprojectname$.Interfaces.External;
public interface IExternalService
{
}
