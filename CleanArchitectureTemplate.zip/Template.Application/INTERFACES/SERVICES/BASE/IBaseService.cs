﻿namespace $safeprojectname$.Interfaces.Services.Base;
public interface IBaseService
{
}
